﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ELuna_Module02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnC1_Click(object sender, EventArgs e)
        {
            const double Kilometers = 1.6;
            int miles;
            double total;

            miles = Convert.ToInt32(txtM2K.Text);
            total = miles * Kilometers;
            A1.Text = miles + " miles is " + total.ToString() + " kilometers.";

        }

        private void btnC2_Click(object sender, EventArgs e)
        {
            double days;
            double miles;
            double total;

            days = Convert.ToInt32(txtDays.Text);
            miles = Convert.ToInt32(txtMiles.Text);
            days = 20 * days;
            miles = .25 * miles;
            total = days + miles;
            A2.Text = "$" + total + " is the rental fee.";
        }

        private void btnC3_Click(object sender, EventArgs e)
        {
            double F;
            double C;

            F = Convert.ToInt32(txtFahrenheit.Text);
            C = ((F - 32)) * (5 / 9);
            A3.Text = "The temperature in Fahrenheit is " + F + " and the temperature in Celsius is " + C;
        }
    }
}
