﻿namespace ELuna_Module02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.P1 = new System.Windows.Forms.Label();
            this.btnC1 = new System.Windows.Forms.Button();
            this.btnC2 = new System.Windows.Forms.Button();
            this.btnC3 = new System.Windows.Forms.Button();
            this.txtM2K = new System.Windows.Forms.TextBox();
            this.txtDays = new System.Windows.Forms.TextBox();
            this.txtMiles = new System.Windows.Forms.TextBox();
            this.txtFahrenheit = new System.Windows.Forms.TextBox();
            this.A1 = new System.Windows.Forms.Label();
            this.A2 = new System.Windows.Forms.Label();
            this.A3 = new System.Windows.Forms.Label();
            this.P3 = new System.Windows.Forms.Label();
            this.Q1 = new System.Windows.Forms.Label();
            this.P2 = new System.Windows.Forms.Label();
            this.Q2 = new System.Windows.Forms.Label();
            this.Q3 = new System.Windows.Forms.Label();
            this.Q4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // P1
            // 
            this.P1.AutoSize = true;
            this.P1.Location = new System.Drawing.Point(194, 54);
            this.P1.Name = "P1";
            this.P1.Size = new System.Drawing.Size(94, 13);
            this.P1.TabIndex = 0;
            this.P1.Text = "Miles to Kilometers";
            // 
            // btnC1
            // 
            this.btnC1.Location = new System.Drawing.Point(387, 82);
            this.btnC1.Name = "btnC1";
            this.btnC1.Size = new System.Drawing.Size(105, 37);
            this.btnC1.TabIndex = 1;
            this.btnC1.Text = "Convert M2K";
            this.btnC1.UseVisualStyleBackColor = true;
            this.btnC1.Click += new System.EventHandler(this.btnC1_Click);
            // 
            // btnC2
            // 
            this.btnC2.Location = new System.Drawing.Point(387, 166);
            this.btnC2.Name = "btnC2";
            this.btnC2.Size = new System.Drawing.Size(105, 37);
            this.btnC2.TabIndex = 2;
            this.btnC2.Text = "Calculate Rental Fee";
            this.btnC2.UseVisualStyleBackColor = true;
            this.btnC2.Click += new System.EventHandler(this.btnC2_Click);
            // 
            // btnC3
            // 
            this.btnC3.Location = new System.Drawing.Point(387, 250);
            this.btnC3.Name = "btnC3";
            this.btnC3.Size = new System.Drawing.Size(105, 37);
            this.btnC3.TabIndex = 3;
            this.btnC3.Text = "Convert F2C";
            this.btnC3.UseVisualStyleBackColor = true;
            this.btnC3.Click += new System.EventHandler(this.btnC3_Click);
            // 
            // txtM2K
            // 
            this.txtM2K.Location = new System.Drawing.Point(188, 82);
            this.txtM2K.Name = "txtM2K";
            this.txtM2K.Size = new System.Drawing.Size(100, 20);
            this.txtM2K.TabIndex = 5;
            // 
            // txtDays
            // 
            this.txtDays.Location = new System.Drawing.Point(81, 175);
            this.txtDays.Name = "txtDays";
            this.txtDays.Size = new System.Drawing.Size(100, 20);
            this.txtDays.TabIndex = 6;
            // 
            // txtMiles
            // 
            this.txtMiles.Location = new System.Drawing.Point(260, 175);
            this.txtMiles.Name = "txtMiles";
            this.txtMiles.Size = new System.Drawing.Size(100, 20);
            this.txtMiles.TabIndex = 7;
            // 
            // txtFahrenheit
            // 
            this.txtFahrenheit.Location = new System.Drawing.Point(188, 259);
            this.txtFahrenheit.Name = "txtFahrenheit";
            this.txtFahrenheit.Size = new System.Drawing.Size(100, 20);
            this.txtFahrenheit.TabIndex = 8;
            // 
            // A1
            // 
            this.A1.AutoSize = true;
            this.A1.Location = new System.Drawing.Point(523, 94);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(11, 13);
            this.A1.TabIndex = 9;
            this.A1.Text = "*";
            // 
            // A2
            // 
            this.A2.AutoSize = true;
            this.A2.Location = new System.Drawing.Point(523, 178);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(11, 13);
            this.A2.TabIndex = 10;
            this.A2.Text = "*";
            // 
            // A3
            // 
            this.A3.AutoSize = true;
            this.A3.Location = new System.Drawing.Point(523, 262);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(11, 13);
            this.A3.TabIndex = 11;
            this.A3.Text = "*";
            // 
            // P3
            // 
            this.P3.AutoSize = true;
            this.P3.Location = new System.Drawing.Point(185, 229);
            this.P3.Name = "P3";
            this.P3.Size = new System.Drawing.Size(105, 13);
            this.P3.TabIndex = 12;
            this.P3.Text = "Fahrenheit to Celsius";
            // 
            // Q1
            // 
            this.Q1.AutoSize = true;
            this.Q1.Location = new System.Drawing.Point(99, 85);
            this.Q1.Name = "Q1";
            this.Q1.Size = new System.Drawing.Size(83, 13);
            this.Q1.TabIndex = 13;
            this.Q1.Text = "Miles to Convert";
            // 
            // P2
            // 
            this.P2.AutoSize = true;
            this.P2.Location = new System.Drawing.Point(194, 147);
            this.P2.Name = "P2";
            this.P2.Size = new System.Drawing.Size(93, 13);
            this.P2.TabIndex = 14;
            this.P2.Text = "Cramer Car Rental";
            // 
            // Q2
            // 
            this.Q2.AutoSize = true;
            this.Q2.Location = new System.Drawing.Point(12, 178);
            this.Q2.Name = "Q2";
            this.Q2.Size = new System.Drawing.Size(65, 13);
            this.Q2.TabIndex = 15;
            this.Q2.Text = "Days Driven";
            // 
            // Q3
            // 
            this.Q3.AutoSize = true;
            this.Q3.Location = new System.Drawing.Point(194, 178);
            this.Q3.Name = "Q3";
            this.Q3.Size = new System.Drawing.Size(65, 13);
            this.Q3.TabIndex = 16;
            this.Q3.Text = "Miles Driven";
            // 
            // Q4
            // 
            this.Q4.AutoSize = true;
            this.Q4.Location = new System.Drawing.Point(78, 262);
            this.Q4.Name = "Q4";
            this.Q4.Size = new System.Drawing.Size(109, 13);
            this.Q4.TabIndex = 17;
            this.Q4.Text = "Fahrenheit to Convert";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Q4);
            this.Controls.Add(this.Q3);
            this.Controls.Add(this.Q2);
            this.Controls.Add(this.P2);
            this.Controls.Add(this.Q1);
            this.Controls.Add(this.P3);
            this.Controls.Add(this.A3);
            this.Controls.Add(this.A2);
            this.Controls.Add(this.A1);
            this.Controls.Add(this.txtFahrenheit);
            this.Controls.Add(this.txtMiles);
            this.Controls.Add(this.txtDays);
            this.Controls.Add(this.txtM2K);
            this.Controls.Add(this.btnC3);
            this.Controls.Add(this.btnC2);
            this.Controls.Add(this.btnC1);
            this.Controls.Add(this.P1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label P1;
        private System.Windows.Forms.Button btnC1;
        private System.Windows.Forms.Button btnC2;
        private System.Windows.Forms.Button btnC3;
        private System.Windows.Forms.TextBox txtM2K;
        private System.Windows.Forms.TextBox txtDays;
        private System.Windows.Forms.TextBox txtMiles;
        private System.Windows.Forms.TextBox txtFahrenheit;
        private System.Windows.Forms.Label A1;
        private System.Windows.Forms.Label A2;
        private System.Windows.Forms.Label A3;
        private System.Windows.Forms.Label P3;
        private System.Windows.Forms.Label Q1;
        private System.Windows.Forms.Label P2;
        private System.Windows.Forms.Label Q2;
        private System.Windows.Forms.Label Q3;
        private System.Windows.Forms.Label Q4;
    }
}

